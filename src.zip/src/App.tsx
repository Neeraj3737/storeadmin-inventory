import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import InventoryOverview from './pages/InventoryOverview';
import ProductDetails from './pages/ProductDetails';
import CategoryOverview from './pages/CategoryOverview';
import './App.css';

const App: React.FC = () => {
  return (
    <Router>
      <div className="App">
        <Navbar />
        <main className="App-main">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/inventory" element={<InventoryOverview />} />
            <Route path="/product/:id" element={<ProductDetails />} />
            <Route path="/categories" element={<CategoryOverview />} />
            <Route path="/categories/:category" element={<CategoryOverview />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
};

export default App;

