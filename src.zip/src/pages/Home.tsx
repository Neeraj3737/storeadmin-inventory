import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css';

const Home: React.FC = () => {
  return (
    <div className="home-container">
      <div className="home-hero">
        <h1 className="home-title">Welcome to Inventory Manager</h1>
        <p className="home-subtitle">
          Your comprehensive solution for managing store inventory efficiently
        </p>
      </div>

      <div className="home-features">
        <div className="feature-card">
          <div className="feature-icon">📊</div>
          <h2 className="feature-title">Inventory Overview</h2>
          <p className="feature-description">
            Browse your entire product catalog with advanced filtering, sorting, and search capabilities. 
            View product details including price, brand, category, and stock status at a glance.
          </p>
          <Link to="/inventory" className="feature-button">
            View Inventory
          </Link>
        </div>

        <div className="feature-card">
          <div className="feature-icon">🗂️</div>
          <h2 className="feature-title">Category Overview</h2>
          <p className="feature-description">
            Explore your inventory by category. Get a hierarchical view of all product categories 
            and drill down into specific categories to see related products.
          </p>
          <Link to="/categories" className="feature-button">
            Browse Categories
          </Link>
        </div>
      </div>

      <div className="home-capabilities">
        <h2 className="capabilities-title">Key Capabilities</h2>
        <div className="capabilities-grid">
          <div className="capability-item">
            <span className="capability-icon">🔍</span>
            <h3>Quick Search</h3>
            <p>Find products instantly with real-time search</p>
          </div>
          <div className="capability-item">
            <span className="capability-icon">📱</span>
            <h3>Responsive Design</h3>
            <p>Works seamlessly on desktop, tablet, and mobile</p>
          </div>
          <div className="capability-item">
            <span className="capability-icon">⚡</span>
            <h3>Fast & Efficient</h3>
            <p>Optimized data loading and smooth performance</p>
          </div>
          <div className="capability-item">
            <span className="capability-icon">📈</span>
            <h3>Smart Filtering</h3>
            <p>Filter by category and sort by price or name</p>
          </div>
          <div className="capability-item">
            <span className="capability-icon">🔗</span>
            <h3>Related Products</h3>
            <p>Discover similar products for cross-selling</p>
          </div>
          <div className="capability-item">
            <span className="capability-icon">📦</span>
            <h3>Stock Management</h3>
            <p>Monitor stock levels and availability</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;

