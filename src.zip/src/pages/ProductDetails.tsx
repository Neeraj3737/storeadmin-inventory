import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { fetchProduct, fetchProductsByCategory, Product } from '../services/api';
import ProductCard from '../components/ProductCard';
import Loading from '../components/Loading';
import ErrorDisplay from '../components/ErrorDisplay';
import './ProductDetails.css';

const ProductDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [similarProducts, setSimilarProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [loadingSimilar, setLoadingSimilar] = useState<boolean>(false);

  useEffect(() => {
    const loadProduct = async () => {
      if (!id) return;
      
      setLoading(true);
      setError(null);
      try {
        const data = await fetchProduct(id);
        setProduct(data);
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Failed to load product';
        setError(errorMessage);
      } finally {
        setLoading(false);
      }
    };
    loadProduct();
  }, [id]);

  useEffect(() => {
    const loadSimilarProducts = async () => {
      if (!product?.category) return;
      
      setLoadingSimilar(true);
      try {
        const data = await fetchProductsByCategory(product.category, 6);
        // Exclude current product from similar products
        const filtered = data.products.filter(p => p.id !== product.id);
        setSimilarProducts(filtered.slice(0, 5)); // Show max 5 similar products
      } catch (err) {
        console.error('Error loading similar products:', err);
      } finally {
        setLoadingSimilar(false);
      }
    };
    loadSimilarProducts();
  }, [product]);

  if (loading) {
    return (
      <div className="product-details-container">
        <Loading message="Loading product details..." />
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="product-details-container">
        <ErrorDisplay 
          message={error || 'Product not found'} 
          onRetry={() => navigate('/inventory')}
        />
      </div>
    );
  }

  const stockStatus = product.stock > 0 ? 'In Stock' : 'Out of Stock';
  const stockClass = product.stock > 0 ? 'in-stock' : 'out-of-stock';

  return (
    <div className="product-details-container">
      <button onClick={() => navigate(-1)} className="back-button">
        ← Back
      </button>

      <div className="product-details">
        <div className="product-details-images">
          <div className="product-main-image">
            <img src={product.thumbnail} alt={product.title} />
          </div>
          {product.images && product.images.length > 1 && (
            <div className="product-image-gallery">
              {product.images.slice(0, 4).map((image, index) => (
                <img key={index} src={image} alt={`${product.title} ${index + 1}`} />
              ))}
            </div>
          )}
        </div>

        <div className="product-details-info">
          <h1 className="product-details-title">{product.title}</h1>
          
          <div className="product-details-meta">
            <span className="product-brand">Brand: {product.brand}</span>
            <span className="product-category">Category: {product.category}</span>
            {product.rating && (
              <div className="product-rating">
                <span className="rating-stars">{'★'.repeat(Math.floor(product.rating))}</span>
                <span className="rating-value">{product.rating.toFixed(1)}</span>
                <span className="rating-count">({product.reviews?.length || 0} reviews)</span>
              </div>
            )}
          </div>

          <div className="product-details-price">
            <span className="price-current">${product.price}</span>
            {product.discountPercentage > 0 && (
              <>
                <span className="price-original">
                  ${((product.price * 100) / (100 - product.discountPercentage)).toFixed(2)}
                </span>
                <span className="price-discount">
                  {Math.round(product.discountPercentage)}% OFF
                </span>
              </>
            )}
          </div>

          <div className={`product-stock ${stockClass}`}>
            <strong>Stock Status:</strong> {stockStatus} ({product.stock} units available)
          </div>

          {product.description && (
            <div className="product-description">
              <h2>Description</h2>
              <p>{product.description}</p>
            </div>
          )}

          <div className="product-specs">
            <h2>Product Details</h2>
            <ul>
              {product.brand && <li><strong>Brand:</strong> {product.brand}</li>}
              <li><strong>Category:</strong> {product.category}</li>
              <li><strong>Price:</strong> ${product.price}</li>
              {product.discountPercentage > 0 && (
                <li><strong>Discount:</strong> {Math.round(product.discountPercentage)}%</li>
              )}
              <li><strong>Stock:</strong> {product.stock} units</li>
              {product.rating && <li><strong>Rating:</strong> {product.rating.toFixed(1)}/5.0</li>}
            </ul>
          </div>
        </div>
      </div>

      {similarProducts.length > 0 && (
        <div className="similar-products">
          <h2 className="similar-products-title">Browse Similar Products</h2>
          {loadingSimilar ? (
            <Loading message="Loading similar products..." />
          ) : (
            <div className="similar-products-grid">
              {similarProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ProductDetails;

