import React, { useState, useEffect, useMemo } from 'react';
import { fetchProducts, searchProducts, fetchCategories, fetchProductsByCategory, Product, CategoryObject } from '../services/api';
import ProductCard from '../components/ProductCard';
import Loading from '../components/Loading';
import ErrorDisplay from '../components/ErrorDisplay';
import './InventoryOverview.css';

interface InventoryOverviewProps {
  categoryFilter?: string | null;
}

const InventoryOverview: React.FC<InventoryOverviewProps> = ({ categoryFilter: initialCategoryFilter = null }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'name' | 'price'>('name');
  const [categoryFilter, setCategoryFilter] = useState<string | null>(initialCategoryFilter);
  const [skip, setSkip] = useState<number>(0);
  const [hasMore, setHasMore] = useState<boolean>(true);
  const [isSearching, setIsSearching] = useState<boolean>(false);

  const limit = 20;

  // Fetch categories on mount
  useEffect(() => {
    const loadCategories = async () => {
      try {
        const cats = await fetchCategories();
        // Handle both string array and object array formats
        const categoriesArray = Array.isArray(cats) ? cats : [];
        
        // Extract category slugs from objects, or use strings directly
        const validCategories = categoriesArray
          .map((cat: CategoryObject | string): string | null => {
            if (typeof cat === 'string') return cat.trim();
            if (cat && typeof cat === 'object' && 'slug' in cat) return (cat as CategoryObject).slug;
            if (cat && typeof cat === 'object' && 'name' in cat) {
              return (cat as CategoryObject).name.toLowerCase().replace(/\s+/g, '-');
            }
            return null;
          })
          .filter((cat): cat is string => cat !== null && cat.trim().length > 0);
        
        setCategories(validCategories);
      } catch (err) {
        console.error('Error loading categories:', err);
      }
    };
    loadCategories();
  }, []);

  // Fetch products
  useEffect(() => {
    const loadProducts = async () => {
      if (isSearching) return; // Don't load regular products when searching
      
      setLoading(true);
      setError(null);
      try {
        // If we have an initial category filter, fetch products by category
        if (initialCategoryFilter) {
          const data = await fetchProductsByCategory(initialCategoryFilter, limit * 2); // Fetch more for category view
          setProducts(data.products || []);
          setHasMore(false); // Category view shows all products, no pagination needed
        } else {
          const data = await fetchProducts(limit, skip);
          if (skip === 0) {
            setProducts(data.products);
          } else {
            setProducts(prev => [...prev, ...data.products]);
          }
          setHasMore(data.products.length === limit);
        }
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Failed to load products';
        setError(errorMessage);
      } finally {
        setLoading(false);
      }
    };
    loadProducts();
  }, [skip, isSearching, initialCategoryFilter]);

  // Search products with debounce
  useEffect(() => {
    if (!searchQuery.trim()) {
      setIsSearching(false);
      setSkip(0);
      return;
    }

    const timeoutId = setTimeout(async () => {
      setIsSearching(true);
      setLoading(true);
      setError(null);
      try {
        const data = await searchProducts(searchQuery);
        setProducts(data.products || []);
        setHasMore(false);
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Failed to search products';
        setError(errorMessage);
      } finally {
        setLoading(false);
      }
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [searchQuery]);

  // Filter and sort products
  const filteredAndSortedProducts = useMemo(() => {
    let result = [...products];

    // Apply category filter
    if (categoryFilter) {
      result = result.filter(p => p.category === categoryFilter);
    }

    // Apply sorting
    result.sort((a, b) => {
      if (sortBy === 'name') {
        return a.title.localeCompare(b.title);
      } else if (sortBy === 'price') {
        return a.price - b.price;
      }
      return 0;
    });

    return result;
  }, [products, categoryFilter, sortBy]);

  const loadMore = () => {
    if (!loading && hasMore && !isSearching) {
      setSkip(prev => prev + limit);
    }
  };

  const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setCategoryFilter(e.target.value || null);
  };

  if (error && products.length === 0) {
    return (
      <div className="inventory-container">
        <ErrorDisplay message={error} onRetry={() => window.location.reload()} />
      </div>
    );
  }

  return (
    <div className="inventory-container">
      <div className="inventory-header">
        <h1 className="inventory-title">
          {initialCategoryFilter 
            ? `${initialCategoryFilter.charAt(0).toUpperCase() + initialCategoryFilter.slice(1)} Products` 
            : 'Inventory Overview'}
        </h1>
      </div>

      <div className="inventory-controls">
        <div className="search-container">
          <input
            type="text"
            placeholder="Search products by name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="search-input"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="search-clear"
              aria-label="Clear search"
            >
              ×
            </button>
          )}
        </div>

        <div className="filter-controls">
          {!initialCategoryFilter && (
            <select
              value={categoryFilter || ''}
              onChange={handleCategoryChange}
              className="category-filter"
            >
              <option value="">All Categories</option>
              {categories.map(cat => {
                const categoryName = typeof cat === 'string' ? cat : String(cat || '');
                return (
                  <option key={categoryName} value={categoryName}>
                    {categoryName.charAt(0).toUpperCase() + categoryName.slice(1)}
                  </option>
                );
              })}
            </select>
          )}

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'name' | 'price')}
            className="sort-select"
          >
            <option value="name">Sort by Name</option>
            <option value="price">Sort by Price (Low to High)</option>
          </select>
        </div>
      </div>

      {loading && products.length === 0 ? (
        <Loading message="Loading products..." />
      ) : (
        <>
          <div className="products-grid">
            {filteredAndSortedProducts.length > 0 ? (
              filteredAndSortedProducts.map(product => (
                <ProductCard key={product.id} product={product} showFullDetails />
              ))
            ) : (
              <div className="no-products">
                <p>No products found.</p>
              </div>
            )}
          </div>

          {hasMore && !isSearching && !categoryFilter && (
            <div className="load-more-container">
              <button
                onClick={loadMore}
                disabled={loading}
                className="load-more-button"
              >
                {loading ? 'Loading...' : 'Load More Products'}
              </button>
            </div>
          )}

          {filteredAndSortedProducts.length > 0 && (categoryFilter || isSearching) && (
            <div className="results-count">
              Showing {filteredAndSortedProducts.length} product{filteredAndSortedProducts.length !== 1 ? 's' : ''}
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default InventoryOverview;

