import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import './Navbar.css';

const Navbar: React.FC = () => {
  const location = useLocation();

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <Link to="/" className="navbar-logo">
          <span className="navbar-logo-icon">📦</span>
          <span className="navbar-logo-text">Inventory Manager</span>
        </Link>
        <div className="navbar-links">
          <Link 
            to="/" 
            className={`navbar-link ${location.pathname === '/' ? 'active' : ''}`}
          >
            Home
          </Link>
          <Link 
            to="/inventory" 
            className={`navbar-link ${location.pathname === '/inventory' ? 'active' : ''}`}
          >
            Inventory Overview
          </Link>
          <Link 
            to="/categories" 
            className={`navbar-link ${location.pathname === '/categories' ? 'active' : ''}`}
          >
            Categories
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

