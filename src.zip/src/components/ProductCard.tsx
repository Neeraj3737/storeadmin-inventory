import React from 'react';
import { Link } from 'react-router-dom';
import { Product } from '../services/api';
import './ProductCard.css';

interface ProductCardProps {
  product: Product;
  showFullDetails?: boolean;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, showFullDetails = false }) => {
  const stockStatus = product.stock > 0 ? 'In Stock' : 'Out of Stock';
  const stockClass = product.stock > 0 ? 'in-stock' : 'out-of-stock';

  return (
    <Link to={`/product/${product.id}`} className="product-card-link">
      <div className="product-card">
        <div className="product-card-image-container">
          <img 
            src={product.thumbnail} 
            alt={product.title}
            className="product-card-image"
            loading="lazy"
          />
          {product.discountPercentage > 0 && (
            <span className="product-card-discount">
              -{Math.round(product.discountPercentage)}%
            </span>
          )}
        </div>
        <div className="product-card-content">
          <h3 className="product-card-title">{product.title}</h3>
          {showFullDetails && (
            <>
              <p className="product-card-brand">Brand: {product.brand}</p>
              <p className="product-card-category">Category: {product.category}</p>
            </>
          )}
          <div className="product-card-footer">
            <div className="product-card-price">
              <span className="price-current">${product.price}</span>
              {product.discountPercentage > 0 && (
                <span className="price-original">
                  ${((product.price * 100) / (100 - product.discountPercentage)).toFixed(2)}
                </span>
              )}
            </div>
            <span className={`product-card-stock ${stockClass}`}>
              {stockStatus} ({product.stock})
            </span>
          </div>
          {product.rating && (
            <div className="product-card-rating">
              <span className="rating-stars">★</span>
              <span className="rating-value">{product.rating.toFixed(1)}</span>
            </div>
          )}
        </div>
      </div>
    </Link>
  );
};

export default ProductCard;

